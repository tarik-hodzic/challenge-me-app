package com.example.challengeme.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.challengeme.viewmodel.RandomChallengeViewModel

@Composable
fun RandomChallengeScreen() {
    val context = LocalContext.current
    var refreshTrigger by remember { mutableStateOf(false) }

    val viewModel: RandomChallengeViewModel = remember(refreshTrigger) {
        RandomChallengeViewModel(context)
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(colors = listOf(Color(0xFF0D1117), Color(0xFF1F2A48)))
            )
            .padding(horizontal = 18.dp, vertical = 26.dp)
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "🎯 Random Challenges",
            fontSize = 30.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Text(
            text = "🕒 New challenges every 24h.\nComplete them to grow your streak!",
            fontSize = 15.sp,
            color = Color(0xFFB0BEC5),
            style = TextStyle(lineHeight = 20.sp),
            modifier = Modifier.padding(bottom = 24.dp),
        )

        viewModel.randomChallenges.forEachIndexed { index, challenge ->
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF263859)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
                    .shadow(6.dp, RoundedCornerShape(20.dp))
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "${index + 1}. $challenge",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 24.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    if (viewModel.completedStatus.contains(index)) {
                        Text(
                            text = "✅ Challenge completed!",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF66BB6A)
                        )
                    } else {
                        Button(
                            onClick = { viewModel.markCompleted(index) },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF42A5F5))
                        ) {
                            Text("Complete", color = Color.White, fontSize = 15.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(36.dp))

        Button(
            onClick = {
                context.getSharedPreferences("random_challenge_prefs", Context.MODE_PRIVATE)
                    .edit()
                    .clear()
                    .apply()
                refreshTrigger = !refreshTrigger
            },
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935)),
            modifier = Modifier
                .wrapContentWidth()
                .height(52.dp)
        ) {
            Text(
                text = "🔁 Reset Challenges",
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}
