package com.example.challengeme.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun DashboardScreen(navController: NavController, userId: Int) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF141E30), Color(0xFF243B55))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "👋 Welcome Back!",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            DashboardButton(
                text = "🗓️  Daily Challenge",
                onClick = { navController.navigate("daily") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            DashboardButton(
                text = "🎲  Random Challenge",
                onClick = { navController.navigate("random") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            DashboardButton(
                text = "🔥  Streak",
                onClick = { navController.navigate("streak") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            DashboardButton(
                text = "⚙️  Settings",
                onClick = { navController.navigate("settings") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ✅ Dodano dugme za profil korisnika
            DashboardButton(
                text = "👤  Profile",
                onClick = { navController.navigate("profile/$userId") }
            )
        }
    }
}

@Composable
fun DashboardButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A6BA5)),
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
    ) {
        Text(
            text = text,
            fontSize = 18.sp,
            color = Color.White,
            fontWeight = FontWeight.Medium
        )
    }
}
