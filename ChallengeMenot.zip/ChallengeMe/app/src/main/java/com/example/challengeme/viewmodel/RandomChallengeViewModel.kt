package com.example.challengeme.viewmodel

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class RandomChallengeViewModel(context: Context) : ViewModel() {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("random_challenge_prefs", Context.MODE_PRIVATE)

    var randomChallenges by mutableStateOf<List<String>>(emptyList())
    var completedStatus by mutableStateOf<MutableSet<Int>>(mutableSetOf())
        private set

    private val allChallenges = listOf(
        "Stretch for 15 minutes", "Write a short poem", "Try a new workout",
        "Call someone you love", "Eat 3 different vegetables", "No sugar for a day",
        "Organize your emails", "Read 15 pages", "Help someone unexpectedly",
        "Limit social media to 30 min", "Practice breathing", "Meditate 10 minutes",
        "Clean up a folder on your PC", "Learn a fun fact", "Take a photo of nature",
        "Write down 5 goals", "Watch a documentary", "Avoid caffeine today",
        "Declutter a drawer", "Recycle something today"
    )

    init {
        loadChallenges()
    }

    private fun loadChallenges() {
        val lastGenerated = prefs.getLong("random_last_generated", 0L)
        val now = System.currentTimeMillis()
        val json = prefs.getString("random_challenges", null)

        if (now - lastGenerated >= 24 * 60 * 60 * 1000 || json == null) {
            val newChallenges = allChallenges.shuffled().take(10)
            saveChallenges(newChallenges)
        } else {
            val type = object : TypeToken<List<String>>() {}.type
            randomChallenges = Gson().fromJson(json, type)
            completedStatus = prefs.getStringSet("random_completed", emptySet())
                ?.map { it.toInt() }?.toMutableSet() ?: mutableSetOf()
        }
    }

    private fun saveChallenges(list: List<String>) {
        randomChallenges = list
        completedStatus = mutableSetOf()
        val json = Gson().toJson(list)
        prefs.edit()
            .putString("random_challenges", json)
            .putLong("random_last_generated", System.currentTimeMillis())
            .putStringSet("random_completed", emptySet())
            .apply()
    }

    fun markCompleted(index: Int) {
        completedStatus = completedStatus.toMutableSet().apply { add(index) }
        prefs.edit().putStringSet(
            "random_completed",
            completedStatus.map { it.toString() }.toSet()
        ).apply()
    }
}
