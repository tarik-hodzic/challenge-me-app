package com.example.challengeme.viewmodel

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import java.util.concurrent.TimeUnit

class DailyChallengeViewModel(private val context: Context) : ViewModel() {

    private val prefs = context.getSharedPreferences("daily_challenge_prefs", Context.MODE_PRIVATE)

    private val challengeList = listOf(
        "Walk 10,000 steps today", "Drink 8 glasses of water", "Write down 3 things you're grateful for",
        "Do 15 pushups", "Read 10 pages of a book", "Meditate for 5 minutes",
        "Learn one new word", "Compliment someone genuinely", "Try a new healthy recipe"
    )

    var currentChallenge = mutableStateOf("")
    var isChallengeCompleted = mutableStateOf(false)

    init {
        loadChallenge()
    }

    private fun loadChallenge() {
        val lastTime = prefs.getLong("last_generated_time", 0L)
        val now = System.currentTimeMillis()
        val elapsed = now - lastTime

        if (elapsed > TimeUnit.HOURS.toMillis(24) || prefs.getString("challenge", null) == null) {
            val newChallenge = challengeList.random()
            saveChallenge(newChallenge, false, now)
            currentChallenge.value = newChallenge
            isChallengeCompleted.value = false
        } else {
            currentChallenge.value = prefs.getString("challenge", "") ?: ""
            isChallengeCompleted.value = prefs.getBoolean("completed", false)
        }
    }

    fun completeChallenge() {
        isChallengeCompleted.value = true
        prefs.edit()
            .putBoolean("completed", true)
            .apply()
    }

    private fun saveChallenge(challenge: String, completed: Boolean, time: Long) {
        prefs.edit()
            .putString("challenge", challenge)
            .putBoolean("completed", completed)
            .putLong("last_generated_time", time)
            .apply()
    }
}
